<?php

namespace App\Observers;

use App\Events\CreateCommunityEvent;
use App\Models\Community;
use App\Models\User;
use Mockery\Exception;

class CommunityObServe
{
    /**
     * Handle the Community "created" event.
     */
    public function creating(Community $community): void
    {
        $community->last_update=now();
    }

    public function created(Community $community): void
    {
        try{
          //  event(new CreateCommunityEvent($community));
        }catch (Exception | \Error $e){}
        if($community->is_global){
            User::chunk(1000, function ($users) use ($community) {
                $userIds = $users->pluck('id')->toArray();
                $community->users()->syncWithoutDetaching($userIds);
            });

        }
        if($community->manager_id!=null){
           $user= $community->manager;
           $community->users()->syncWithPivotValues([$user->id],['is_manager'=>true,]);
        }elseif (auth()->check()){
            $community->users()->syncWithPivotValues([auth()->id()],['is_manager'=>true,]);
        }

    }

    /**
     * Handle the Community "updated" event.
     */
    public function updated(Community $community): void
    {
        //
    }

    /**
     * Handle the Community "deleted" event.
     */
    public function deleted(Community $community): void
    {
        //
    }

    /**
     * Handle the Community "restored" event.
     */
    public function restored(Community $community): void
    {
        //
    }

    /**
     * Handle the Community "force deleted" event.
     */
    public function forceDeleted(Community $community): void
    {
        //
    }
}
